import javax.swing.JOptionPane;

public class GUIApp {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		
		JOptionPane.showMessageDialog(null, "Sup", null, 0);

	}

}
